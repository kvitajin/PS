![Lineární graf](https://imgur.com/mkNKWfo.png)  
  
![Logaritmický graf](https://imgur.com/C1ZzGGH.png) 
  
![Snapdragon 855+](https://imgur.com/pcNTTZ3.png) 
